Gnapplet from Gnokii (www.gnokii.org)
licensed with GNU GPL2
version 0.18
should work with many Series 60 1st, 2nd edition and other (Symbian 6.x - 8.x)
