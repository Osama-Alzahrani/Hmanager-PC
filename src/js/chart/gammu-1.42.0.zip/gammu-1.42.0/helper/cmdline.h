#ifndef __helper_cmdline_h__
#define __helper_cmdline_h__

/**
 * Returns integer from string or terminates program on failure.
 */
long int GetInt(const char* param);

#endif

/* How should editor hadle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8 tw=78:
 */

