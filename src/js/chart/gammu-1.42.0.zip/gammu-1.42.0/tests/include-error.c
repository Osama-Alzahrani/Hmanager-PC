/* Automatically generated test for validating header file gammu-error.h */
/* See gen-include-test.sh for details */

#include <gammu-error.h>
#include <gammu-error.h>

/* We do not want to push another header, so we need to copy definiton of UNUSED */
#ifndef UNUSED
# if __GNUC__
#  define UNUSED __attribute__ ((unused))
# else
#  define UNUSED
# endif
#endif

int main(int argc UNUSED, char **argv UNUSED)
{
	return 0;
}
