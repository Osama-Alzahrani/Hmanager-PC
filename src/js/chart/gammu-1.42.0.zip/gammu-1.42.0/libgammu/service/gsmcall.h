/* (c) 2002-2003 by Marcin Wiacek */

#ifndef _gsm_call_h
#define _gsm_call_h

#include "../misc/misc.h"


#endif

/* How should editor hadle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8:
 */
