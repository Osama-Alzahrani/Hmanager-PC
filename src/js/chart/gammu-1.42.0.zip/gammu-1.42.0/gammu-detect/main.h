extern gint debug;

extern void print_config(const gchar *device, const gchar *name, const gchar *connection);
