/**
 * Null SMSD service.
 *
 * This service does not store anything anywhere.
 */
/* Copyright (c) 2010 - 2018 Michal Cihar <michal@cihar.com>. */

extern GSM_SMSDService SMSDNull;

/* How should editor hadle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8:
 */
