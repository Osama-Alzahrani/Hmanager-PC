/* Clearing messages: */
{0x2A, "2.5", "RELEASE COMPLETE"},
/* Miscellaneous message group: */
{0x3A, "2.3", "FACILITY"},
{0x3B, "2.4", "REGISTER"},
{-1, NULL, NULL}
/* Unused sections
*/
