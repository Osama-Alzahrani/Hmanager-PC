/* xsiemens.h */

int siemens_code(char*, char*, int);
